Blogger Template Style
---------------------------------------------
Template Name :  Light Blue
Designed by   :  Bloggets
URL           :  http://bloggets.blogspot.com
Date          :  June 2010
---------------------------------------------


INSTRUCTIONS:

1. Back Up your existing template first before you upload new template.
   
   Go to Edit HTML, and then click Download Full Template and save it. 



UPLOADING THE THEME:

1. Go to Blogger Dashboard > Design > Edit HTML.

2. Click on the Browse Button and upload the XML file.

3. Click on the Save button.



------------------------------------------------------------

For more Blogger Templates Visit www.bloggets.blogspot.com



