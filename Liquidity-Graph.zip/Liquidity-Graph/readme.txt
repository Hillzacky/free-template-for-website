How to upload Blogger templates

1. Download your Blogger XML template from http://www.newbloggertemplates.com.  
The template is contained in a zip file (winzip, winrar), ensure you have extracted the XML template.
2. Log in to your Blogger dashboard and go to Layout > Edit HTML
3. Ensure you back up your old template in case you decide to use it again. To do this, click on the "download full template" link and save the file to your hard drive.
4. Look for the section near the top where you can browse for your XML template:
5. Enter the location of your template and press "upload".
6. The HTML of your new template will now appear in the box below. You can preview your template or simply save to start using it!
7. Enjoy!

www.newbloggertemplates.com
"Every Day With Latest Blogger Templates"