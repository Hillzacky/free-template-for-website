Important !!!

For Configuration and widget codes of this template visit here:

-----------------------------------------------------------------------------------------------

http://www.premiumbloggertemplates.com/2010/08/lk-magazine-v3-premium-blogger-template.html


-----------------------------------------------------------------------------------------------





Template Installation 

1.First download the template and unzip the file. 

2.Now, sign in to Blogger dashboard and click on the layout.

3.Here is the important step, after uploading any new Blogger template, all of the previous widgets like your google adsense ads,text,profile,poll,etc etc will be lost.
So, to avoid this to happen, in this step click on 'edit' on all the widgets and copy the codes into notepad,etc.

4.Now click on the 'Edit html' tab

5.First of all please Download Full Template.This is to back up your present template.If the new template that you are going to upload makes/gets into some errors or if you make more complex errors in that,then you will loose everthing.So make sure that you back up your template.

6.Just below that,there's an option of uploading new template.So, use the Browse button and upload the downloaded xml file.

7.Now, a message appear saying that your widgets are about to be deleted.Click on the Confirm & Save (no problem doing this because we already copied the widget codes in Step 3).

8.Now click on "confirm and save".Now you successfully installed the template.

8.Click on the 'Page elements' page now and add the codes that you copied in step3 using the 'Add a Page Element' option.



http://www.premiumbloggertemplates.com/



Blogger Tips And Tricks:

http://www.bloggertipandtrick.net/

