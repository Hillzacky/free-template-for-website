var $jx = jQuery.noConflict(); 
$jx(document).ready(function() {
	$jx("#tabzine> ul").tabs({ fx: { opacity: 'toggle' } }).tabs('rotate', 5000); 
	$jx('#newtabs> ul').tabs({ fx: {  opacity: 'toggle' } }); 

});
