jQuery(document).ready(function() {
Cufon.replace('.blogname', { fontFamily: 'Rockwell' });
jQuery('#tabnav').customScroller(); 

});

