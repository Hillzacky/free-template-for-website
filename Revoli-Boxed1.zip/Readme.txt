This template is a property of www.oddthemes.com and this is a encrypted version which has limited features and less customization like:
-Encrypted Code
-No Documentation
-Less Customization
-Footer Credits >> Which are irremovable, because removing footer links will redirect your website to www.oddthemes.com.
To enable all the customizations and to remove footer links you have to purchase this template from this link: http://shop.oddthemes.com/blogger/revoli-responsive-blogger-template/


Instructions to this template: http://www.oddthemes.com/2014/07/revoli-responsive-blogger-template.html