jQuery(document).ready(function() {

Cufon.replace('.blogname h1', { fontFamily: 'Myriad Pro' });

});