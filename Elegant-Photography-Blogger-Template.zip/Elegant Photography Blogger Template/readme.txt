How To Install Blogger Theme

1. Go To Blogger Dashboard
2. Click On Template Tab.
3. Now Click on Backup/Restore button.
4. Upload XML file of theme which I have provided to you there.


For any type of help contact me @ http://www.seobloggertemplates.com/p/contact-us.html