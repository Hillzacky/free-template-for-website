This template is a property of www.oddthemes.com and this is a encrypted version which has limited features and less customization. 

To enable all the customizations and features you have to purchase this template from this link: http://shop.oddthemes.com/downloads/hellya-responsive-blogger-template


